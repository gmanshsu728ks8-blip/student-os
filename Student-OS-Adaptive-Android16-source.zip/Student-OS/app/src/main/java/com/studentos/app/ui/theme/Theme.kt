package com.studentos.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StudentOsDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = OnBlue,
    primaryContainer = BlueContainer,
    onPrimaryContainer = ColorTokens.OnBlueContainer,
    secondary = ColorTokens.DarkSecondary,
    onSecondary = Midnight,
    background = Midnight,
    onBackground = Cloud,
    surface = Navy,
    onSurface = Cloud,
    surfaceVariant = NavyHigh,
    onSurfaceVariant = Slate,
    surfaceContainerLowest = Midnight,
    surfaceContainerLow = Navy,
    surfaceContainer = NavyRaised,
    surfaceContainerHigh = NavyHigh,
    surfaceContainerHighest = NavyHigh,
    outline = SlateStrong,
    outlineVariant = ColorTokens.DarkOutline,
    error = DarkError,
)

private val StudentOsLightColorScheme = lightColorScheme(
    primary = ElectricBlueDark,
    onPrimary = White,
    primaryContainer = Color(0xFFDCE8FF),
    onPrimaryContainer = Color(0xFF102D61),
    secondary = Color(0xFF526783),
    onSecondary = White,
    background = Cloud,
    onBackground = Color(0xFF111B2B),
    surface = LightSurface,
    onSurface = Color(0xFF111B2B),
    surfaceVariant = LightSurfaceAlt,
    onSurfaceVariant = Color(0xFF52627A),
    surfaceContainerLowest = White,
    surfaceContainerLow = Color(0xFFF0F4FA),
    surfaceContainer = White,
    surfaceContainerHigh = Color(0xFFE8EEF7),
    surfaceContainerHighest = Color(0xFFDDE6F2),
    outline = Color(0xFF71839D),
    outlineVariant = LightOutline,
    error = ErrorRed,
)

private object ColorTokens {
    val OnBlueContainer = Color(0xFFDCE8FF)
    val DarkSecondary = Color(0xFFB6C8E8)
    val DarkOutline = Color(0xFF344761)
}

/** Follows the device appearance automatically; Arabic/English follows Android app-language settings. */
@Composable
fun StudentOsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) StudentOsDarkColorScheme else StudentOsLightColorScheme,
        typography = StudentOsTypography,
        shapes = StudentOsShapes,
        content = content,
    )
}
