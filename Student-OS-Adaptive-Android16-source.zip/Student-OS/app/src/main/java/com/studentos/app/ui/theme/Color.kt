package com.studentos.app.ui.theme

import androidx.compose.ui.graphics.Color

// Student OS identity: deep navy surfaces with a crisp electric-blue accent.
internal val Midnight = Color(0xFF080D18)
internal val Navy = Color(0xFF101A2B)
internal val NavyRaised = Color(0xFF17243A)
internal val NavyHigh = Color(0xFF22334D)
internal val Slate = Color(0xFF9AAAC2)
internal val SlateStrong = Color(0xFF536780)
internal val ElectricBlue = Color(0xFF78A6FF)
internal val ElectricBlueDark = Color(0xFF245BC4)
internal val BlueContainer = Color(0xFF1B3768)
internal val OnBlue = Color(0xFF06152F)
internal val Cloud = Color(0xFFF4F7FC)
internal val White = Color(0xFFFFFFFF)
internal val LightSurface = Color(0xFFFFFFFF)
internal val LightSurfaceAlt = Color(0xFFEAF0F8)
internal val LightOutline = Color(0xFFD5DFEC)
internal val ErrorRed = Color(0xFFBA1A1A)
internal val DarkError = Color(0xFFFFB4AB)
