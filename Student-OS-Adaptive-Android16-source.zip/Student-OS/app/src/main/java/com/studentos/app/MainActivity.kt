package com.studentos.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import com.studentos.app.navigation.StudentOsNavHost
import com.studentos.app.ui.theme.StudentOsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StudentOsTheme {
                StudentOsNavHost()
            }
        }
    }
}
